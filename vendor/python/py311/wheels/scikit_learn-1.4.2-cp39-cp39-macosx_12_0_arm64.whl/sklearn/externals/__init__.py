
"""
External, bundled dependencies.

"""
